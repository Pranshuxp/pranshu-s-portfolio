# How to update your GitHub Pages portfolio

1. Go to: https://github.com/pranshuxp/pranshu-s-portfolio
2. Click the "Add file" button → "Upload files"
3. Drag and drop all files from this folder
4. Click "Commit changes"

Your site will update automatically at:
https://pranshuxp.github.io/pranshu-s-portfolio/

Note: Make sure to upload ALL files including:
- HTML files (index.html, etc.)
- assets folder (with images)
- styles.css
- script.js